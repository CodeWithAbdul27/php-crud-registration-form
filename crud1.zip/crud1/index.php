<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!------ Include the above in your HEAD tag ---------->
    <link rel="stylesheet" href="./css/style.css">

    <style>
        label {
            font-weight: 600;
        }
    </style>
</head>

<body>


    <div class="wrapper rounded bg-white">

        <div class="h3 text-center">Registration Form</div>
        <div class="line"></div>

        <div class="form">
            <form method="post" action="insert_data.php">
                <div class="row">
                    <div class="col-md-6 mt-md-0 mt-3">
                        <label>First Name</label>
                        <input type="text" class="form-control" name="firstname">
                    </div>
                    <div class="col-md-6 mt-md-0 mt-3">
                        <label>Last Name</label>
                        <input type="text" class="form-control" name="lastname">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mt-md-0 mt-3">
                        <label>Father Name</label>
                        <input type="text" class="form-control" name="fathername">
                    </div>
                    <div class="col-md-6 mt-md-0 mt-3">
                        <label>Gender</label>
                        <div class="d-flex align-items-center mt-2">
                            <label class="option" style="margin-right:8px;">
                                <input class="checkmark" type="radio" name="gender" value="male">  Male
                                <!-- <span class="checkmark"></span> -->
                            </label>
                            <label class="option ms-4">
                                <input class="checkmark" type="radio" name="gender" value="female">  Female
                                <!-- <span class="checkmark"></span> -->
                            </label>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mt-md-0 mt-3">
                        <label>Email</label>
                        <input type="email" class="form-control" name="email">
                    </div>
                    <div class="col-md-6 mt-md-0 mt-3">
                        <label>Phone Number</label>
                        <input type="tel" class="form-control" name="phone">
                    </div>
                </div>
                <button type="submit" name="submit" class="btn btn-success mt-3">Submit</button>

                <a href="display.php" class="btn btn-warning mt-3" style="float:right;">Display Records</a>

            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

</body>

</html>