<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!------ Include the above in your HEAD tag ---------->
    <link rel="stylesheet" href="./css/style.css">

    <style>
        label {
            font-weight: 600;
        }
    </style>
</head>

<body>

    <div class="wrapper rounded bg-white" style="width:1140px;">
        <div class="h3 text-center">All Records</div>
        <div class="line" style="width: 120px;margin-left:44%;"></div>

        <table class="table table-striped table-bordered" style="margin-top:1rem;">
            <thead>
                <tr>
                    <th>Sr. no</th>
                    <th>Firstname</th>
                    <th>Lastname</th>
                    <th>Fathername</th>
                    <th>Gender</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>

            </tbody>
        </table>
        <a href="index.php" class="btn btn-warning mt-3" style="float:right;">Register Now</a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

</body>

</html>